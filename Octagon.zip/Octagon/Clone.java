public interface Clone extends Cloneable, Comparable {
    Clone clone();

}

import java.util.Objects;

public class MyInteger {
    private int value;

    public MyInteger(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public boolean isEven() {
        return isEven(value);
    }

    public boolean isOdd() {
        return isOdd(value);
    }

    public boolean isPrime() {
        return isPrime(value);
    }

    public static boolean isEven(int myValue) {
        return (myValue % 2 == 0);
    }

    public static boolean isOdd(int myValue) {
        return (myValue % 2 != 0);
    }

    public static boolean isPrime(int myValue) {
        if (myValue == 1 || myValue == 2) {
            return true;
        }

            for (int i = 2; i < myValue; i++) {
                if (i % myValue == 0) {
                    return false;
                }
            }
            return true;
        }

    public static boolean isEven(MyInteger number) {
        return number.isEven();
    }

    public static boolean isOdd(MyInteger number) {
        return number.isOdd();
    }

    public static boolean isPrime(MyInteger number) {
        return number.isPrime();
    }

    public boolean equals(int myValue) {
        return value == myValue;
    }

    public boolean equals(MyInteger number) {
        return equals(number.getValue());
    }

    public static int parseInt(char[] s) {
        return parseInt(new String(s));
    }

    public static int parseInt(String s) {
        return Integer.parseInt(s);
    }

    public static void main(String[] args) {
        MyInteger value = new MyInteger(10);


        boolean isEven = value.isEven();
        System.out.println("Is 'value' even: " + isEven);


        boolean isOdd = value.isOdd();
        System.out.println("Is 'value' odd: " + isOdd);


        boolean isPrime = value.isPrime();
        System.out.println("Is 'value' prime: " + isPrime);


        int myValue = 20;

        boolean isEvenStatic = MyInteger.isEven(myValue);
        System.out.println("Is 'myValue' even: " + isEvenStatic);

        // Call static isOdd(int) method
        boolean isOddStatic = MyInteger.isOdd(myValue);
        System.out.println("Is 'myValue' odd: " + isOddStatic);

        // Call static isPrime(int) method
        boolean isPrimeStatic = MyInteger.isPrime(myValue);
        System.out.println("Is 'myValue' prime: " + isPrimeStatic);

        int number = 25;

        boolean isEven3 = MyInteger.isEven(number);
        System.out.println("Is 'number' even: " + isEven3);

        boolean isOdd3 = MyInteger.isOdd(number);
        System.out.println("is 'number' odd: " + isOdd3);

        boolean isPrime3 = MyInteger.isPrime(number);
        System.out.println("Is 'number' prime: " + isPrime3);

        int value3 = 10;

        boolean isEqual = value.equals(value3);
        System.out.println("Is equal: " + isEqual);

        MyInteger myInt2 = new MyInteger(11);

        boolean isEqual2 = value.equals(myInt2);
        System.out.println("Is 'value' and 'myInt2' equal: " + isEqual2);


        int parseInt = MyInteger.parseInt(new String("454"));
        System.out.println(parseInt);



        int parseInt2 = MyInteger.parseInt(new char[] {'1', '5', '4'});
        System.out.println(parseInt2);

    }
}


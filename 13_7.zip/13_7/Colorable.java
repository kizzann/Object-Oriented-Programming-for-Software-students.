public interface Colorable {

   String howToColor();
   }

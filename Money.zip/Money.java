package Money;
import java.util.Date;
import java.util.Scanner;

public class Money {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        main2();
//
//        Account account = new Account(1122, 20000);
//        account.setAnnualInterestRate(4.5);
//        account.withdraw(2500);
//        account.deposit(3000);
//        System.out.println("Balance: $" + account.getBalance());
//        System.out.println("Monthly Interest: " + account.getMonthlyInterest());
//        System.out.println("Date created: " + account.getDateCreated());
    }

    static class Account {
        private int ID = 0;
        private double balance = 0;
        private double annualInterestRate = 0;
        private Date dateCreated;

        private int someData;

        public Account() {
            dateCreated = new Date();
        }

        public Account(int ID, double balance) {
            this();
            this.ID = ID;
            this.balance = balance;
        }

        public int getID() {
            return ID;
        }

        public void setID(int ID) {
            this.ID = ID;
        }

        public double getBalance() {
            return balance;
        }

        public void setBalance(double balance) {
            if (balance > 10000000) return;
            if (balance < 0) return;
            this.balance = balance;
        }

        public double getAnnualInterestRate() {
            return annualInterestRate;
        }

        public void setAnnualInterestRate(double annualInterestRate) {
            this.annualInterestRate = annualInterestRate;
        }

        public Date getDateCreated() {
            return dateCreated;
        }

        public void setDateCreated(Date dateCreated) {
            this.dateCreated = dateCreated;
        }

        public double getMonthlyInterestRate() {
            return annualInterestRate / 12;
        }

        public double getMonthlyInterest() {
            return balance * (getAnnualInterestRate() / 100);
        }

        public void withdraw(double amountToWithdraw) {
            balance -= amountToWithdraw;
        }

        public void deposit(double amountToDeposit) {
            balance += amountToDeposit;
        }
    }

    public static void main2() {
        final Scanner input = new Scanner(System.in);
        Account[] accounts = new Account[10];

        for (int i = 0; i < 10; i++) {
            accounts[i] = new Account(i, 100.00);
        }

        System.out.print("Enter an ID (1-10): ");
        int id = input.nextInt();

        if (id < 1 || id > 10) {
            id = incorrectId(id);
        }
        while (true) {
            menuDisplay();
            System.out.print("Enter a choice: ");
            int choice = input.nextInt();

            if (choice == 4) {
                System.out.println("Enter an ID (1-10): ");
                id = input.nextInt();

                if (id < 1 || id > 10) {
                    id = incorrectId(id);
                }
            }
            menuOptions(id, choice, accounts);
        }
    }

    public static int incorrectId(int id) {
        Scanner input = new Scanner(System.in);
        while(id < 1 || id > 10) {
            System.out.println("Please enter a valid ID: ");
            id = input.nextInt();
            System.out.println();
        }
        return id;
    }
    public static void menuOptions(int id, int choice, Account[] accounts) {
        Scanner input = new Scanner(System.in);
        switch(choice) {
            case 1:
                System.out.print("The balance of your account is: " + accounts[id].getBalance());
                break;
            case 2:
                System.out.print("Enter the amount you want to withdraw: ");
            accounts[id].withdraw(input.nextDouble());
                break;
            case 3:
                System.out.print("Enter the amount you want to deposit: ");
                accounts[id].deposit(input.nextDouble());
                break;
            default:
                break;
        }
    }

    public static void menuDisplay() {
        System.out.print("\nMenu options\n");
        System.out.println("1: View checking balance");
        System.out.println("2: Withdraw money");
        System.out.println("3: Deposit money");
        System.out.println("4: Exit");
    }

}